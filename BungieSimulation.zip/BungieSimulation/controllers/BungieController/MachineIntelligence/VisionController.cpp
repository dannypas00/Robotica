#include "VisionController.h"

namespace bungie {
void VisionController::Subscribe(std::string object)
{
	return;
}

Vector3 VisionController::See()
{
	return Vector3(5, 6, 7);
}
}