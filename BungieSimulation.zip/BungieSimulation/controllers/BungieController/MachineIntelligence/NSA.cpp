#include "NSA.h"

namespace bungie {
int NSA::ExecuteAssignment(MIStrategy& assignment)
{
    assignment.ExecuteStrategy();
	return 0;
}
}