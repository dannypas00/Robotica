#ifndef WEIGHT_SENSOR
#define WEIGHT_SENSOR

namespace bungie {
class WeightSensor
{
private:
	float value;
public:
	float GetWeight();
};
}

#endif