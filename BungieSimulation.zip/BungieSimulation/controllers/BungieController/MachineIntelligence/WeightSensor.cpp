#include "WeightSensor.h"

namespace bungie {
float WeightSensor::GetWeight()
{
	return 0.0f;
}
}