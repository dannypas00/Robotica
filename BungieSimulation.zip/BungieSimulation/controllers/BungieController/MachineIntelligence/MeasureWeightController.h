#ifndef MEASURE_WEIGHT_CONTROLLER
#define MEASURE_WEIGHT_CONTROLLER
//#include "NSA.h"

namespace bungie {
class MeasureWeightController {
private:
	int weightSensor;
	//NSA* display;
public:
	MeasureWeightController() = default;
	int a = 15;
};
}

#endif