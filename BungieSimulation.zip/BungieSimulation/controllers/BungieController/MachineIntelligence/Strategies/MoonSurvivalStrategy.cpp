#include "MoonSurvivalStrategy.h"
#include <iostream>

namespace bungie {
int MoonSurvivalStrategy::ExecuteStrategy()
{
	//Done
	return 0;
}
}