#include "MoonMazeStrategy.h"

namespace bungie {
MoonMazeStrategy::MoonMazeStrategy() {
}

int MoonMazeStrategy::ExecuteStrategy()
{
	// Execute pathfinding here
	
	//Done
	return 0;
}
}